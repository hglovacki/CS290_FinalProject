# Auto-fit and minmax

